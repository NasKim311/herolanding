package com.hero.herolanding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HerolandingApplicationTests {

	@Test
	void contextLoads() {
	}

}
