package com.hero.herolanding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HerolandingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HerolandingApplication.class, args);
	}

}
